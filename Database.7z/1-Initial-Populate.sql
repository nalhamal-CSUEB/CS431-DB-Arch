INSERT INTO Department
	(Dept_name,Location)
VALUES
	('Finance', 'B5'),
	('Admin', 'B1'),
	('Maintenance','B2'),
	('Accounts Receivable','B5'),
	('Human Resources','B1'),
	('IT','B3'),
	('Customer Service','A4'),
	('Shipping','A1');